export const App = () => (
  <div>
    <h1>Heroes App</h1>
  </div>
);
