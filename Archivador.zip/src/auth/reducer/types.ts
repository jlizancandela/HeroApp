export const types = {
  LOGIN: 'LOGIN',
  LOGOUT: 'LOGOUT',
};
