import { Hero } from "./types";
import data from "./heroes.json";
export const heroes: Hero[] = data;
export * from "./types";
