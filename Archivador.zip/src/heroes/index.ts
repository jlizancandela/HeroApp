export { MarvelPage } from './pages/marvel';
export { DcPage } from './pages/dc';
export { HeroPage } from './pages/hero';
export { SearchPage } from './pages/search';
