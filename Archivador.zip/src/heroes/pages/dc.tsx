import { Heroes } from "../components/heroes";

export const DcPage = () => {
  return (
    <div>
      <h1>DcPage</h1>
      <Heroes publisher="dc" />
    </div>
  );
};
