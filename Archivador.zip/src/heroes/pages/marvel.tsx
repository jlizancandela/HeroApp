import { Heroes } from "../components/heroes";

export const MarvelPage = () => {
  return (
    <div>
      <h1>MarvelPage</h1>
      <Heroes publisher="marvel" />
    </div>
  );
};
